package com.streambox.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "streambox_session")

class TokenStore(private val context: Context) {
    private val tokenKey = stringPreferencesKey("access_token")

    suspend fun save(token: String) {
        context.dataStore.edit { it[tokenKey] = token }
    }

    suspend fun get(): String? =
        context.dataStore.data.map { it[tokenKey] }.first()

    suspend fun clear() {
        context.dataStore.edit { it.remove(tokenKey) }
    }
}
